assert SECTION(Undefined)
